javac Dijkstra.java DijkstraApp.java
java DijkstraApp $1