javac Dijkstra.java Johnson.java JohnsonApp.java
java JohnsonApp $1