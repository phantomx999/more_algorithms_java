javac finiteAutomaton.java finiteAutomatonApp.java
java finiteAutomatonApp $1