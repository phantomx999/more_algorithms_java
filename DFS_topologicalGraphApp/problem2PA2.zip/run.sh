javac Vertex.java topologicalGraphApp.java topologicalGraph.java
java topologicalGraphApp $1